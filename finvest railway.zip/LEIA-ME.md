# 🚀 Como subir o FinVest Bot no Railway

## Passo 1 — Criar conta
1. Acesse https://railway.app
2. Clique em "Login" e entre com sua conta do GitHub (crie uma se não tiver, é grátis)

## Passo 2 — Subir os arquivos
Você tem duas opções:

### Opção A — Via GitHub (recomendado)
1. Crie um repositório no GitHub (pode ser privado)
2. Suba TODOS estes arquivos para o repositório:
   - finvest_bot_v5.py
   - requirements.txt
   - Procfile
   - runtime.txt
   - .gitignore
3. No Railway: "New Project" → "Deploy from GitHub repo" → escolha seu repositório

### Opção B — Upload direto
1. No Railway: "New Project" → "Empty Project"
2. Arraste os arquivos (não suba os arquivos .json de config)

## Passo 3 — Configurar o token (IMPORTANTE)
1. No projeto do Railway, clique na aba "Variables"
2. Clique em "New Variable"
3. Nome: `BOT_TOKEN`
4. Valor: cole o seu token do BotFather
5. Salve

## Passo 4 — Deploy
1. O Railway vai instalar tudo e rodar automaticamente
2. Veja os logs na aba "Deployments" — deve aparecer "Rodando!"
3. Abra o Telegram e mande /start

## Pronto! 🎉
Agora o bot fica online 24h, mesmo com seu PC desligado.
- Briefing às 8h ✅
- PDF às 18h ✅
- Alertas a cada 30min ✅

## Observações
- O plano gratuito do Railway dá ~500h/mês de execução. Para 24h/dia o mês todo,
  considere o plano Hobby (~US$5/mês).
- Os arquivos de tarefas/alertas/config são salvos no servidor do Railway.
  Em redeploys eles podem ser resetados (Railway usa armazenamento efêmero por padrão).
  Se quiser persistência total, adicione um "Volume" no Railway.
